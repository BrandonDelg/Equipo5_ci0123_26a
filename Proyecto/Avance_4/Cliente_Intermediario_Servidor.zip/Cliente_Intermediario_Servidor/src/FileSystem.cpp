#include "FileSystem.hpp"
#include <cstring>
#include <sstream>
#include <algorithm>
#include <iostream>
FileSystem::FileSystem(const std::string& filename) {
    disk.open(filename, std::ios::in | std::ios::out | std::ios::binary);

    if (!disk.is_open()) {
        disk.open(filename, std::ios::out | std::ios::binary);
        disk.close();

        disk.open(filename, std::ios::in | std::ios::out | std::ios::binary);

        init();
    }
}

void FileSystem::init() {
    char buffer[BLOCK_SIZE] = {0};

    SuperBlock sb;
    sb.blockSize = BLOCK_SIZE;
    sb.totalBlocks = 100;
    sb.rootDirBlock = 2;
    sb.bitmapBlock = 1;

    memcpy(buffer, &sb, sizeof(sb));
    writeBlock(0, buffer);

    memset(buffer, 0, BLOCK_SIZE);
    buffer[0] = 1; // superblock
    buffer[1] = 1; // bitmap
    buffer[2] = 1; // root dir
    writeBlock(1, buffer);

    DirBlock dir = {};
    dir.nextBlock = -1;

    memset(buffer, 0, BLOCK_SIZE);
    memcpy(buffer, &dir, sizeof(dir));
    writeBlock(2, buffer);
}


void FileSystem::readBlock(int blockNum, char* buffer) {
    disk.seekg(blockNum * BLOCK_SIZE);
    disk.read(buffer, BLOCK_SIZE);
}

void FileSystem::writeBlock(int blockNum, const char* buffer) {
    disk.seekp(blockNum * BLOCK_SIZE);
    disk.write(buffer, BLOCK_SIZE);
    disk.flush();
}


int FileSystem::allocateBlock() {
    char buffer[BLOCK_SIZE];
    readBlock(1, buffer);

    for (int i = 0; i < BLOCK_SIZE; i++) {
        if (buffer[i] == 0) {
            buffer[i] = 1;
            writeBlock(1, buffer);
            return i;
        }
    }
    return -1;
}

void FileSystem::crearFigura(const std::string& nombre, const std::string& contenido) {
    Inode inode;
    inode.size = contenido.size();
    if (buscarFigura(nombre) != -1) {
        //std::cout << "La figura ya existe: " << nombre << std::endl;
        borrarFigura(nombre);
        //return;
    }

    for (int i = 0; i < 8; i++) {
        inode.blocks[i] = -1;
    }

    int bytesWritten = 0;
    int blockIndex = 0;

    while (bytesWritten < (int)contenido.size() && blockIndex < 8) {
        int block = allocateBlock();
        char buffer[BLOCK_SIZE] = {0};
        int chunk = std::min(BLOCK_SIZE, (int)contenido.size() - bytesWritten);
        memcpy(buffer, contenido.c_str() + bytesWritten, chunk);
        writeBlock(block, buffer);
        inode.blocks[blockIndex++] = block;
        bytesWritten += chunk;
    }

    int inodeBlock = allocateBlock();

    char buffer[BLOCK_SIZE] = {0};
    memcpy(buffer, &inode, sizeof(inode));
    writeBlock(inodeBlock, buffer);

    int current = 2;

    while (true) {
        readBlock(current, buffer);
        DirBlock* dir = (DirBlock*)buffer;

        for (int i = 0; i < 4; i++) {
            if (dir->entries[i].nombre[0] == '\0') {
                strcpy(dir->entries[i].nombre, nombre.c_str());
                dir->entries[i].inodeBlock = inodeBlock;

                writeBlock(current, buffer);
                return;
            }
        }

        if (dir->nextBlock == -1) {
            int newBlock = allocateBlock();

            DirBlock newDir = {};
            newDir.nextBlock = -1;

            char newBuffer[BLOCK_SIZE] = {0};
            memcpy(newBuffer, &newDir, sizeof(newDir));
            writeBlock(newBlock, newBuffer);

            dir->nextBlock = newBlock;
            writeBlock(current, buffer);

            current = newBlock;
        } else {
            current = dir->nextBlock;
        }
    }
}

std::vector<std::string> FileSystem::getFiguras() {
    std::vector<std::string> figuras;
    char buffer[BLOCK_SIZE];

    int current = 2;

    while (current != -1) {
        readBlock(current, buffer);
        DirBlock* dir = (DirBlock*)buffer;

        for (int i = 0; i < 4; i++) {
            if (dir->entries[i].nombre[0] != '\0') {
                figuras.push_back(dir->entries[i].nombre);
            }
        }

        current = dir->nextBlock;
    }

    return figuras;
}
int FileSystem::buscarFigura(const std::string& nombre) {
    char buffer[BLOCK_SIZE];
    int current = 2;

    while (current != -1) {
        readBlock(current, buffer);
        DirBlock* dir = (DirBlock*)buffer;

        for (int i = 0; i < 4; i++) {
            if (nombre == dir->entries[i].nombre) {
                return dir->entries[i].inodeBlock;
            }
        }

        current = dir->nextBlock;
    }

    return -1;
}

std::string FileSystem::getPiezas(const std::string& figura, int mitad) {
    int inodeBlock = buscarFigura(figura);

    if (inodeBlock == -1) {
        return "";
    }

    int total = 0;
    char buffer[BLOCK_SIZE];
    readBlock(inodeBlock, buffer);

    Inode* inode = (Inode*)buffer;

    std::string contenido;
    int remaining = inode->size;

    for (int i = 0; i < 8 && remaining > 0; i++) {
        if (inode->blocks[i] == -1) break;

        char data[BLOCK_SIZE];
        readBlock(inode->blocks[i], data);

        int chunk = std::min(BLOCK_SIZE, remaining);

        contenido.append(data, chunk);

        remaining -= chunk;
    }

    std::istringstream iss(contenido);
    std::string linea, resultado;
    bool leyendo = false;
    while (std::getline(iss, linea)) {
    if (linea == std::to_string(mitad)) {
        leyendo = true;
        continue;
    }

    if (leyendo) {
        if (linea == "1" || linea == "2") break;
        size_t pos = linea.find(':');
        if (pos != std::string::npos) {
            std::string pieza = linea.substr(0, pos);
            std::string cantidad = linea.substr(pos + 1);
            total += std::stoi(cantidad);
            resultado += cantidad + " : " + pieza + "\n";
        } else {
            resultado += linea + "\n";
        }
    }
}
    if (total != 0) {
        resultado += "\nTotal de piezas para armar la mitad " +
            std::to_string(mitad) +
            " de la Figura(" +
            figura +
            ") es: " +
            std::to_string(total);
    } else {
        resultado += "La mitad: " + std::to_string(mitad) + " ya ha sido consumida";
    }
    
    if (resultado.empty()) {
        return "Figura ya ha sido consumida";
    }
    consumirMitad(figura, mitad);
    return resultado;
}

void FileSystem::freeBlock(int blockNum) {
    char buffer[BLOCK_SIZE];
    readBlock(1, buffer);
    buffer[blockNum] = 0;
    writeBlock(1, buffer);
}

bool FileSystem::borrarFigura(const std::string& nombre) {
    char buffer[BLOCK_SIZE];
    int current = 2;

    while (current != -1) {
        readBlock(current, buffer);
        DirBlock* dir = (DirBlock*)buffer;
        for (int i = 0; i < 4; i++) {
            if (nombre == dir->entries[i].nombre) {
                int inodeBlock = dir->entries[i].inodeBlock;
                char inodeBuffer[BLOCK_SIZE];
                readBlock(inodeBlock, inodeBuffer);
                Inode* inode = (Inode*)inodeBuffer;

                for (int j = 0; j < 8; j++) {
                    if (inode->blocks[j] != -1) {
                        freeBlock(inode->blocks[j]);
                    }
                }

                freeBlock(inodeBlock);

                memset(&dir->entries[i], 0, sizeof(dir->entries[i]));
                writeBlock(current, buffer);
                return true;
            }
        }
        current = dir->nextBlock;
    }

    return false;
}

std::string FileSystem::leerContenidoFigura(int inodeBlock) {
    char buffer[BLOCK_SIZE];
    readBlock(inodeBlock, buffer);

    Inode* inode = (Inode*)buffer;

    std::string contenido;
    int remaining = inode->size;

    for (int i = 0; i < 8 && remaining > 0; i++) {
        if (inode->blocks[i] == -1) break;

        char data[BLOCK_SIZE];
        readBlock(inode->blocks[i], data);

        int chunk = std::min(BLOCK_SIZE, remaining);
        contenido.append(data, chunk);
        remaining -= chunk;
    }

    return contenido;
}

void FileSystem::escribirContenido(int inodeBlock, const std::string& contenido) {
    char buffer[BLOCK_SIZE];
    readBlock(inodeBlock, buffer);

    Inode inode = *(Inode*)buffer;

    for (int i = 0; i < 8; i++) {
        if (inode.blocks[i] != -1) {
            freeBlock(inode.blocks[i]);
            inode.blocks[i] = -1;
        }
    }

    inode.size = contenido.size();

    int bytesWritten = 0;
    int blockIndex = 0;

    while (bytesWritten < (int)contenido.size() && blockIndex < 8) {
        int block = allocateBlock();

        if (block == -1) {
            break;
        }

        char data[BLOCK_SIZE] = {0};

        int chunk = std::min(BLOCK_SIZE, (int)contenido.size() - bytesWritten);

        memcpy(data, contenido.c_str() + bytesWritten, chunk);

        writeBlock(block, data);

        inode.blocks[blockIndex++] = block;

        bytesWritten += chunk;
    }

    memset(buffer, 0, BLOCK_SIZE);
    memcpy(buffer, &inode, sizeof(Inode));
    writeBlock(inodeBlock, buffer);
}

bool FileSystem::consumirPiezas(const std::string& figura, int mitad) {
    int inodeBlock = buscarFigura(figura);

    if (inodeBlock == -1) {
        return false;
    }

    std::string contenido = leerContenidoFigura(inodeBlock);

    std::istringstream iss(contenido);
    std::ostringstream nuevo;

    std::string linea;
    bool enMitad = false;
    bool consumio = false;

    while (std::getline(iss, linea)) {
        if (linea == "1" || linea == "2") {
            enMitad = (linea == std::to_string(mitad));
            nuevo << linea << "\n";
            continue;
        }

        if (enMitad) {
            size_t pos = linea.find(':');

            if (pos != std::string::npos) {
                std::string pieza = linea.substr(0, pos);
                std::string cantidadStr = linea.substr(pos + 1);

                int cantidad = std::stoi(cantidadStr);

                if (cantidad > 0) {
                    cantidad--;
                    consumio = true;
                }

                nuevo << pieza << ":" << cantidad << "\n";
                continue;
            }
        }

        nuevo << linea << "\n";
    }

    if (!consumio) {
        return false;
    }

    escribirContenido(inodeBlock, nuevo.str());

    return true;
}

bool FileSystem::agregarPiezas(const std::string& figura, int mitad, const std::string& piezasNuevas)
{
    int inodeBlock = buscarFigura(figura);

    if (inodeBlock == -1) {
        std::string contenido = std::to_string(mitad) + "\n" + piezasNuevas;
        crearFigura(figura, contenido);
        return true;
    }

    std::string contenido = leerContenidoFigura(inodeBlock);
    std::istringstream iss(contenido);
    std::ostringstream nuevo;

    std::string linea;
    bool mitadExiste = false;
    bool agregado = false;

    while (std::getline(iss, linea)) {
        nuevo << linea << "\n";

        if (linea == std::to_string(mitad)) {
            mitadExiste = true;

            while (std::getline(iss, linea)) {
                if (linea == "1" || linea == "2") {
                    nuevo << piezasNuevas;
                    agregado = true;
                    nuevo << linea << "\n";
                    break;
                }

                nuevo << linea << "\n";
            }
        }
    }

    if (mitadExiste && !agregado) {
        nuevo << piezasNuevas;
    }

    if (!mitadExiste) {
        nuevo << mitad << "\n";
        nuevo << piezasNuevas;
    }

    escribirContenido(inodeBlock, nuevo.str());
    return true;
}

bool FileSystem::consumirMitad(const std::string& figura, int mitad) {
    int inodeBlock = buscarFigura(figura);

    if (inodeBlock == -1) {
        return false;
    }

    std::string contenido = leerContenidoFigura(inodeBlock);

    std::istringstream iss(contenido);
    std::ostringstream nuevo;

    std::string linea;
    bool eliminar = false;
    bool encontrada = false;

    while (std::getline(iss, linea)) {

        if (linea == std::to_string(mitad)) {
            eliminar = true;
            encontrada = true;
            continue;
        }

        if (eliminar && (linea == "1" || linea == "2")) {
            eliminar = false;
        }

        if (!eliminar) {
            nuevo << linea << "\n";
        }
    }

    if (!encontrada) {
        return false;
    }

    std::string nuevoContenido = nuevo.str();

    if (nuevoContenido.find("1") == std::string::npos &&
        nuevoContenido.find("2") == std::string::npos) {
        borrarFigura(figura);
        return false;
    } else {
        escribirContenido(inodeBlock, nuevoContenido);
    }
    return true;
}